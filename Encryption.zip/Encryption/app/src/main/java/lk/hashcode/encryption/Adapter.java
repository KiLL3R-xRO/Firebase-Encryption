package lk.hashcode.encryption;

public class Adapter {
    public String message,text;


    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
